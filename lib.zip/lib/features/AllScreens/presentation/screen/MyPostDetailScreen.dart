import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:smart_gawali/features/AllScreens/presentation/screen/MyPostScreen.dart';
import 'package:url_launcher/url_launcher.dart';

class MyPostDetailScreen extends StatelessWidget {
  final PostDetail post;

  const MyPostDetailScreen({Key? key, required this.post}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('dd/MM/yyyy');
    final createdAt = DateTime.tryParse(post.createdAt) ?? DateTime.now();

    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.transparent,
        title: Text(
          'Post Details',
          style: TextStyle(
              color: Colors.black, fontWeight: FontWeight.bold, fontSize: 20),
        ),
        centerTitle: false,
        leading: Container(
          margin: EdgeInsets.all(8),
          child: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF2E7D32), Color(0xFFFFFFFF)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),
      ),


      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (post.photo.isNotEmpty)
              SizedBox(
                height: 250,
                child: PageView.builder(
                  itemCount: post.photo.length,
                  controller: PageController(viewportFraction: 0.9),
                  itemBuilder: (context, index) {
                    final imageUrl = post.photo[index];
                    print('Image URL at index $index: $imageUrl'); // 🔍 Debug print

                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4.0),
                      child: Container(
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.green, width: 3),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.network(
                            imageUrl,
                            width: double.infinity,
                            height: 250,
                            fit: BoxFit.cover,
                            loadingBuilder: (context, child, loadingProgress) {
                              if (loadingProgress == null) return child;
                              return Container(
                                color: Colors.grey[200],
                                child: const Center(child: CircularProgressIndicator()),
                              );
                            },
                            errorBuilder: (context, error, stackTrace) => Container(
                              color: Colors.grey[300],
                              child: const Center(
                                child: Icon(Icons.broken_image, size: 40, color: Colors.grey),
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),


            const SizedBox(height: 20),

            _buildSectionTitle('Basic Information'),
            _buildInfoRow('Category', post.categoryName ?? post.catId),
            // _buildInfoRow('Subcategory', post.subcategoryName ?? post.subcategory),
            // if (post.childSubcategory != null)
            //   _buildInfoRow('Child Subcategory', post.childSubcategory!),
            if (post.subcategoryName != null && post.subcategoryName!.trim().isNotEmpty)
              _buildInfoRow('Subcategory', post.subcategoryName!)
            else if (post.subcategory != null && !RegExp(r'^\d+$').hasMatch(post.subcategory!))
              _buildInfoRow('Subcategory', post.subcategory!),

            if (post.childSubcategory != null && post.childSubcategory!.trim().isNotEmpty && !RegExp(r'^\d+$').hasMatch(post.childSubcategory!))
              _buildInfoRow('Child Subcategory', post.childSubcategory!),

            _buildInfoRow('Posted On', dateFormat.format(createdAt)),
            const Divider(height: 30),

            _buildSectionTitle(post.categoryName?.contains('पशु') == true
                ? 'Animal Details'
                : 'Product Details'),
            if (post.name != null) _buildInfoRow('Name', post.name!),
            if (post.price != null) _buildInfoRow('Price', '₹${post.price}'),
            if (post.age != null) _buildInfoRow('Age', '${post.age} years'),
            if (post.weight != null)
              _buildInfoRow('Weight', '${post.weight} ${post.unit ?? ''}'),
            if (post.milk != null) _buildInfoRow('Milk Production', post.milk!),
            if (post.isGhabhan == '1')
              _buildInfoRow('Pregnant',
                  post.ghabhanMonth != null ? 'Yes (${post.ghabhanMonth} months)' : 'Yes'),
            if (post.vet != null) _buildInfoRow('Veterinary Info', post.vet!),
            if (post.useYear != null) _buildInfoRow('Years of Use', post.useYear!),
            const Divider(height: 30),

            _buildSectionTitle('Seller Information'),
            if (post.shopName != null) _buildInfoRow('Shop Name', post.shopName!),
            if (post.address != null) _buildInfoRow('Address', post.address!),
            const Divider(height: 30),

            if (post.description != null) ...[
              _buildSectionTitle('Description'),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Text(
                  post.description!,
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ),
              const Divider(height: 30),
            ],

            // _buildSectionTitle('Additional Information'),
            // _buildInfoRow('Status', post.status == '1' ? 'Active' : 'Inactive'),
            // _buildInfoRow('Views', post.views),
            Padding(
              padding: const EdgeInsets.only(top: 20),
              child: Center(
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.call, color: Colors.white),
                  label: const Text('Call Now',
                      style: TextStyle(color: Colors.white)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green[700],
                    padding: const EdgeInsets.symmetric(
                        horizontal: 30, vertical: 15),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  onPressed: () async {
                    await _makePhoneCall(context, post.mobile);
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: Colors.green,
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              '$label:',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(
            child: Text(value.isNotEmpty ? value : 'Not specified'),
          ),
        ],
      ),
    );
  }
}

Future<void> _makePhoneCall(BuildContext context, String phoneNumber) async {
  final cleanedNumber = phoneNumber.replaceAll(RegExp(r'[^0-9+]'), '');
  final urlsToTry = [
    'tel:$cleanedNumber',
    'tel://$cleanedNumber',
    'telprompt:$cleanedNumber'
  ];

  for (final url in urlsToTry) {
    try {
      if (await canLaunch(url)) {
        await launch(url);
        return;
      }
    } catch (e) {
      continue;
    }
  }

  if (context.mounted) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Could not launch dialer')),
    );
  }
}

